fetch('data/games.json')
  .then(res => res.json())
  .then(games => {
    const grid = document.getElementById('gameGrid');
    games.forEach(game => {
      const card = document.createElement('div');
      card.className = 'game-card';
      card.innerHTML = `<h3>${game.title}</h3><iframe src="${game.url}" loading="lazy"></iframe>`;
      grid.appendChild(card);
    });
  });
